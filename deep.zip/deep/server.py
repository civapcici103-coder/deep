#!/usr/bin/env python3
"""Termux Sentinel OS: local-only system monitor with a small, hardened stdlib server."""
from __future__ import annotations
import hashlib, hmac, json, os, secrets, shutil, sqlite3, subprocess, threading, time
from datetime import datetime, timezone
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

BASE = Path(__file__).resolve().parent
DB_PATH = BASE / 'sentinel.sqlite3'
STATIC = BASE / 'static'
FILES_ROOT = Path(os.environ.get('SENTINEL_FILES_ROOT', str(BASE / 'files'))).expanduser().resolve()
HOST = os.environ.get('SENTINEL_HOST', '127.0.0.1')
PORT = int(os.environ.get('SENTINEL_PORT', '8080'))
SESSION_SECONDS = 12 * 60 * 60
MAX_BODY = 16 * 1024
DB_LOCK = threading.RLock()
CPU_LOCK = threading.Lock()
CPU_PREV = None

SCHEMA = '''
CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, salt BLOB NOT NULL, password_hash BLOB NOT NULL, iterations INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, username TEXT NOT NULL, csrf TEXT NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS login_attempts (ip TEXT NOT NULL, ts INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS login_attempts_ip_ts ON login_attempts(ip, ts);
CREATE TABLE IF NOT EXISTS metrics (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, cpu REAL NOT NULL, mem_total INTEGER NOT NULL, mem_used INTEGER NOT NULL, disk_total INTEGER NOT NULL, disk_used INTEGER NOT NULL, net_rx INTEGER NOT NULL, net_tx INTEGER NOT NULL, battery INTEGER, processes INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS metrics_ts ON metrics(ts);
CREATE TABLE IF NOT EXISTS command_log (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, username TEXT NOT NULL, command TEXT NOT NULL, allowed INTEGER NOT NULL, exit_code INTEGER, output TEXT NOT NULL);
'''
ALLOWED_COMMANDS = {
    'date': ['date', '+%Y-%m-%d %H:%M:%S %Z'],
    'uptime': ['uptime'],
    'disk': ['df', '-h', str(BASE)],
    'identity': ['id'],
    'kernel': ['uname', '-a'],
    'processes': ['ps', '-A', '-o', 'pid,comm,%cpu,%mem'],
}


def connect():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=10000')
    return con


def initialize():
    BASE.mkdir(parents=True, exist_ok=True)
    FILES_ROOT.mkdir(parents=True, exist_ok=True)
    with DB_LOCK, connect() as con:
        con.executescript(SCHEMA)
        exists = con.execute('SELECT 1 FROM users WHERE username=?', ('admin',)).fetchone()
        password_file = Path.home() / '.config' / 'termux-sentinel' / 'initial-admin-password'
        if not exists:
            password = os.environ.get('SENTINEL_ADMIN_PASSWORD')
            if not password:
                password = secrets.token_urlsafe(18)
                password_file.parent.mkdir(parents=True, exist_ok=True)
                password_file.write_text(password + '\n', encoding='utf-8')
                password_file.chmod(0o600)
            if len(password) < 12:
                raise RuntimeError('SENTINEL_ADMIN_PASSWORD must be at least 12 characters')
            salt = secrets.token_bytes(16)
            iterations = 310000
            digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, iterations)
            con.execute('INSERT INTO users VALUES(?,?,?,?)', ('admin', salt, digest, iterations))
            con.commit()


def read_cpu():
    global CPU_PREV
    try:
        parts = Path('/proc/stat').read_text().splitlines()[0].split()[1:]
        vals = list(map(int, parts)); idle = vals[3] + (vals[4] if len(vals) > 4 else 0); total = sum(vals)
        with CPU_LOCK:
            previous = CPU_PREV; CPU_PREV = (total, idle)
        if not previous: return 0.0
        delta_total, delta_idle = total - previous[0], idle - previous[1]
        return round(max(0.0, min(100.0, 100 * (delta_total - delta_idle) / delta_total)), 1) if delta_total else 0.0
    except (OSError, ValueError, IndexError):
        return 0.0


def read_memory():
    try:
        values = {}
        for line in Path('/proc/meminfo').read_text().splitlines():
            key, val = line.split(':', 1); values[key] = int(val.strip().split()[0]) * 1024
        total = values.get('MemTotal', 0); available = values.get('MemAvailable', values.get('MemFree', 0))
        return total, max(0, total - available)
    except (OSError, ValueError, IndexError): return 0, 0


def read_network():
    rx = tx = 0
    try:
        for line in Path('/proc/net/dev').read_text().splitlines()[2:]:
            name, data = line.split(':', 1)
            if name.strip() == 'lo': continue
            cols = data.split(); rx += int(cols[0]); tx += int(cols[8])
    except (OSError, ValueError, IndexError): pass
    return rx, tx


def read_battery():
    try:
        result = subprocess.run(['termux-battery-status'], capture_output=True, text=True, timeout=2, check=False)
        if result.returncode == 0:
            value = json.loads(result.stdout).get('percentage')
            if value is not None: return max(0, min(100, int(value)))
    except (OSError, subprocess.TimeoutExpired, ValueError, TypeError): pass
    for path in Path('/sys/class/power_supply').glob('*/capacity'):
        try: return max(0, min(100, int(path.read_text().strip())))
        except (OSError, ValueError): continue
    return None


def process_list():
    result = []
    proc = Path('/proc')
    try: entries = list(proc.iterdir())
    except OSError: return result
    for entry in entries:
        if not entry.name.isdigit(): continue
        try:
            status = (entry / 'status').read_text(errors='replace')
            name = next((x.split(':', 1)[1].strip() for x in status.splitlines() if x.startswith('Name:')), entry.name)
            uid_line = next((x for x in status.splitlines() if x.startswith('Uid:')), '')
            uid = uid_line.split()[1] if uid_line else '?'
            cmdline = (entry / 'cmdline').read_bytes().replace(b'\0', b' ').decode('utf-8', 'replace').strip()
            result.append({'pid': int(entry.name), 'name': name[:100], 'user': uid, 'command': (cmdline or name)[:240]})
        except (OSError, ValueError, IndexError): continue
    result.sort(key=lambda p: p['pid'])
    return result[:500]


def collect_metrics():
    cpu = read_cpu(); mem_total, mem_used = read_memory(); rx, tx = read_network()
    try:
        disk = shutil.disk_usage(FILES_ROOT); disk_total, disk_used = disk.total, disk.used
    except OSError: disk_total = disk_used = 0
    procs = process_list(); ts = int(time.time())
    row = {'ts': ts, 'cpu': cpu, 'mem_total': mem_total, 'mem_used': mem_used,
           'disk_total': disk_total, 'disk_used': disk_used, 'net_rx': rx, 'net_tx': tx,
           'battery': read_battery(), 'processes': len(procs)}
    with DB_LOCK, connect() as con:
        con.execute('INSERT INTO metrics(ts,cpu,mem_total,mem_used,disk_total,disk_used,net_rx,net_tx,battery,processes) VALUES(:ts,:cpu,:mem_total,:mem_used,:disk_total,:disk_used,:net_rx,:net_tx,:battery,:processes)', row)
        con.execute('DELETE FROM metrics WHERE ts < ?', (ts - 7 * 86400,))
    return row


def metric_worker():
    while True:
        try: collect_metrics()
        except Exception as exc: print(f'metric collection error: {exc}', flush=True)
        time.sleep(2)


def json_bytes(obj): return json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8')

class Handler(BaseHTTPRequestHandler):
    server_version = 'SentinelOS'
    sys_version = ''

    def log_message(self, fmt, *args): print('%s - %s' % (self.address_string(), fmt % args), flush=True)

    def send_bytes(self, code, body, content_type='application/json; charset=utf-8', extra=None):
        self.send_response(code); self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body))); self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY'); self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.send_header('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
        self.send_header('Cache-Control', 'no-store')
        if extra:
            for key, value in extra.items(): self.send_header(key, value)
        self.end_headers()
        if body: self.wfile.write(body)

    def respond(self, code, obj, extra=None): self.send_bytes(code, json_bytes(obj), extra=extra)

    def body_json(self):
        try: length = int(self.headers.get('Content-Length', '0'))
        except ValueError: raise ValueError('Invalid content length')
        if length < 0 or length > MAX_BODY: raise ValueError('Request body too large')
        raw = self.rfile.read(length)
        value = json.loads(raw.decode('utf-8'))
        if not isinstance(value, dict): raise ValueError('JSON object required')
        return value

    def session(self):
        cookie = cookies.SimpleCookie(self.headers.get('Cookie', ''))
        morsel = cookie.get('sentinel_session')
        if not morsel: return None
        token = morsel.value
        if len(token) > 128: return None
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with DB_LOCK, connect() as con:
            row = con.execute('SELECT username,csrf,expires FROM sessions WHERE token_hash=?', (token_hash,)).fetchone()
            if row and row['expires'] > int(time.time()): return {'username': row['username'], 'csrf': row['csrf'], 'token_hash': token_hash}
            if row: con.execute('DELETE FROM sessions WHERE token_hash=?', (token_hash,))
        return None

    def require_auth(self, csrf=False):
        session = self.session()
        if not session:
            self.respond(401, {'error': 'authentication required'}); return None
        if csrf and not hmac.compare_digest(self.headers.get('X-CSRF-Token', ''), session['csrf']):
            self.respond(403, {'error': 'CSRF validation failed'}); return None
        return session

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/':
            try: self.send_bytes(200, (STATIC / 'index.html').read_bytes(), 'text/html; charset=utf-8')
            except OSError: self.respond(500, {'error': 'UI unavailable'})
            return
        if path == '/app.js' or path == '/style.css':
            name = path[1:]
            try: self.send_bytes(200, (STATIC / name).read_bytes(), 'text/javascript; charset=utf-8' if name.endswith('.js') else 'text/css; charset=utf-8')
            except OSError: self.respond(404, {'error': 'not found'})
            return
        if path == '/api/session':
            s = self.session(); self.respond(200, {'authenticated': bool(s), 'username': s['username'] if s else None, 'csrf': s['csrf'] if s else None}); return
        if path == '/api/health': self.respond(200, {'status': 'ok'}); return
        session = self.require_auth()
        if not session: return
        if path == '/api/metrics/current':
            try: row = collect_metrics()
            except Exception:
                with DB_LOCK, connect() as con: row = dict(con.execute('SELECT * FROM metrics ORDER BY ts DESC LIMIT 1').fetchone() or {})
            self.respond(200, row); return
        if path == '/api/metrics/history':
            q = parse_qs(urlparse(self.path).query)
            try:
                since = max(int(q.get('since', [str(int(time.time()) - 3600)])[0]), int(time.time()) - 7 * 86400)
                limit = min(1000, max(1, int(q.get('limit', ['600'])[0])))
            except ValueError: self.respond(400, {'error': 'invalid range'}); return
            with DB_LOCK, connect() as con:
                rows = [dict(r) for r in con.execute('SELECT * FROM metrics WHERE ts>=? ORDER BY ts DESC LIMIT ?', (since, limit)).fetchall()]
            self.respond(200, {'items': rows[::-1]}); return
        if path == '/api/processes': self.respond(200, {'items': process_list()}); return
        if path == '/api/files': self.file_list(); return
        if path == '/api/files/read': self.file_read(); return
        if path == '/api/files/download': self.file_download(); return
        if path == '/api/commands':
            with DB_LOCK, connect() as con:
                rows = [dict(r) for r in con.execute('SELECT id,ts,username,command,allowed,exit_code,output FROM command_log ORDER BY id DESC LIMIT 100')]
            self.respond(200, {'allowed': sorted(ALLOWED_COMMANDS), 'items': rows}); return
        self.respond(404, {'error': 'not found'})

    def do_POST(self):
        path = urlparse(self.path).path
        if path == '/api/login': self.login(); return
        if path == '/api/logout':
            session = self.require_auth(csrf=True)
            if not session: return
            with DB_LOCK, connect() as con: con.execute('DELETE FROM sessions WHERE token_hash=?', (session['token_hash'],))
            self.respond(200, {'ok': True}, {'Set-Cookie': 'sentinel_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'}); return
        session = self.require_auth(csrf=True)
        if not session: return
        if path == '/api/commands/run': self.run_command(session); return
        self.respond(404, {'error': 'not found'})

    def login(self):
        ip = self.client_address[0]
        now = int(time.time())
        with DB_LOCK, connect() as con:
            con.execute('DELETE FROM login_attempts WHERE ts < ?', (now - 900,))
            count = con.execute('SELECT COUNT(*) FROM login_attempts WHERE ip=? AND ts>?', (ip, now - 900)).fetchone()[0]
            if count >= 8:
                self.respond(429, {'error': 'too many attempts'}); return
        try: data = self.body_json()
        except (ValueError, UnicodeError, json.JSONDecodeError): self.respond(400, {'error': 'invalid request'}); return
        username = str(data.get('username', ''))[:128]; password = data.get('password', '')
        if not isinstance(password, str) or len(password) > 1024: password = ''
        with DB_LOCK, connect() as con:
            row = con.execute('SELECT salt,password_hash,iterations FROM users WHERE username=?', (username,)).fetchone()
            # Constant-cost verification for unknown account.
            salt = row['salt'] if row else b'\0' * 16; iterations = row['iterations'] if row else 310000
            digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, iterations)
            valid = bool(row and hmac.compare_digest(digest, row['password_hash']))
            con.execute('INSERT INTO login_attempts(ip,ts) VALUES(?,?)', (ip, now))
            if not valid:
                self.respond(401, {'error': 'invalid username or password'}); return
            con.execute('DELETE FROM login_attempts WHERE ip=?', (ip,))
            token = secrets.token_urlsafe(32); csrf = secrets.token_urlsafe(24)
            con.execute('INSERT INTO sessions(token_hash,username,csrf,expires) VALUES(?,?,?,?)', (hashlib.sha256(token.encode()).hexdigest(), username, csrf, now + SESSION_SECONDS))
        self.respond(200, {'ok': True, 'username': username, 'csrf': csrf}, {'Set-Cookie': f'sentinel_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_SECONDS}'})

    def resolve_file(self, raw):
        if not isinstance(raw, str) or len(raw) > 2048 or '\x00' in raw: raise ValueError('invalid path')
        decoded = unquote(raw)
        if '\x00' in decoded: raise ValueError('invalid path')
        candidate = (FILES_ROOT / decoded.lstrip('/')).resolve(strict=False)
        try: candidate.relative_to(FILES_ROOT)
        except ValueError: raise PermissionError('path outside permitted directory')
        # Resolve and verify symlinks; all returned paths must remain rooted.
        return candidate

    def file_list(self):
        rel = parse_qs(urlparse(self.path).query).get('path', [''])[0]
        try:
            target = self.resolve_file(rel)
            if not target.is_dir(): self.respond(400, {'error': 'directory required'}); return
            items = []
            for p in sorted(target.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))[:500]:
                resolved = p.resolve(strict=False)
                try: resolved.relative_to(FILES_ROOT)
                except ValueError: continue
                try: st = p.stat()
                except OSError: continue
                items.append({'name': p.name, 'path': str(p.relative_to(FILES_ROOT)), 'directory': p.is_dir(), 'size': st.st_size if p.is_file() else None})
            self.respond(200, {'root': str(FILES_ROOT), 'path': str(target.relative_to(FILES_ROOT)) if target != FILES_ROOT else '', 'items': items})
        except PermissionError: self.respond(403, {'error': 'path outside permitted directory'})
        except (ValueError, OSError): self.respond(400, {'error': 'invalid path'})

    def file_read(self):
        raw = parse_qs(urlparse(self.path).query).get('path', [''])[0]
        try:
            target = self.resolve_file(raw)
            if not target.is_file(): self.respond(404, {'error': 'file not found'}); return
            if target.stat().st_size > 1024 * 1024: self.respond(413, {'error': 'file exceeds 1 MiB'}); return
            content = target.read_text(encoding='utf-8')
            self.respond(200, {'name': target.name, 'content': content})
        except PermissionError: self.respond(403, {'error': 'path outside permitted directory'})
        except UnicodeError: self.respond(415, {'error': 'file is not UTF-8 text'})
        except (ValueError, OSError): self.respond(400, {'error': 'invalid path'})

    def file_download(self):
        raw = parse_qs(urlparse(self.path).query).get('path', [''])[0]
        try:
            target = self.resolve_file(raw)
            if not target.is_file(): self.respond(404, {'error': 'file not found'}); return
            if target.stat().st_size > 20 * 1024 * 1024: self.respond(413, {'error': 'file exceeds 20 MiB'}); return
            body = target.read_bytes(); filename = target.name.replace('"', '')[:180]
            self.send_bytes(200, body, 'application/octet-stream', {'Content-Disposition': f'attachment; filename="{filename}"'})
        except PermissionError: self.respond(403, {'error': 'path outside permitted directory'})
        except (ValueError, OSError): self.respond(400, {'error': 'invalid path'})

    def run_command(self, session):
        try: data = self.body_json()
        except (ValueError, UnicodeError, json.JSONDecodeError): self.respond(400, {'error': 'invalid request'}); return
        command = data.get('command')
        if not isinstance(command, str): command = ''
        command = command[:300]
        argv = ALLOWED_COMMANDS.get(command)
        if not argv:
            output = 'Rejected: command is not in the fixed allowlist.'
            with DB_LOCK, connect() as con: con.execute('INSERT INTO command_log(ts,username,command,allowed,exit_code,output) VALUES(?,?,?,?,?,?)', (int(time.time()), session['username'], command, 0, None, output))
            self.respond(403, {'error': 'command not allowed'}); return
        try:
            proc = subprocess.run(argv, cwd=str(BASE), capture_output=True, text=True, timeout=5, check=False, env={'PATH': os.environ.get('PATH', '/system/bin:/usr/bin:/bin'), 'LANG': 'C.UTF-8'})
            output = (proc.stdout + proc.stderr)[:12000]; code = proc.returncode
        except (OSError, subprocess.TimeoutExpired) as exc:
            output = f'Command failed: {type(exc).__name__}'; code = 124
        with DB_LOCK, connect() as con: con.execute('INSERT INTO command_log(ts,username,command,allowed,exit_code,output) VALUES(?,?,?,?,?,?)', (int(time.time()), session['username'], command, 1, code, output))
        self.respond(200, {'command': command, 'exit_code': code, 'output': output})

    def do_HEAD(self):
        self.send_bytes(405, b'', extra={'Allow': 'GET, POST'})


def main():
    initialize()
    threading.Thread(target=metric_worker, name='metrics', daemon=True).start()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    server.daemon_threads = True
    print(f'Termux Sentinel OS listening on http://{HOST}:{PORT}', flush=True)
    print(f'Files root: {FILES_ROOT}', flush=True)
    password_file = Path.home() / '.config' / 'termux-sentinel' / 'initial-admin-password'
    if password_file.exists(): print(f'Initial admin password stored in {password_file}', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__ == '__main__': main()
